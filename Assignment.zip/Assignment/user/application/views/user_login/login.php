<div class="container" style="margin-top: 5%">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <center><h3 class="panel-title">Please do Login here</h3></center>
                </div>
                <?php
                $success_msg= $this->session->flashdata('success_msg');
                $error_msg= $this->session->flashdata('error_msg');
                if($success_msg){
                ?>
                    <center>
                        <div class="alert alert-success">
                            <?php echo $success_msg; ?>
                        </div>
                    </center>
                <?php
                }
                if($error_msg)
                {
                ?>
                    <center>
                        <div class="alert alert-danger">
                            <?php echo $error_msg; ?>
                        </div>
                    </center>    
                <?php
                }
                ?>
                <center>
                <div class="panel-body">
                    <form role="form" method="post" action="<?php echo base_url('./indexCI.php/login/login_user'); ?>">
                        <div class='row'>
                            <div class="col-md-5 text-left">
                                <label>User Email :</label>
                            </div>
                            <div class="col-md-6">
                                <input class="form-control" placeholder="Enter E-mail" name="user_email" type="email" autofocus required>
                            </div>
                        </div>
                        <div class="row">&nbsp;</div>
                        <div class='row'>
                            <div class="col-md-5 text-left">
                                <label>User Password :</label>
                            </div>
                            <div class="col-md-6">
                                <input class="form-control" placeholder="Enter Password" name="user_password" type="password" value="" required>
                            </div>
                        </div>
                        <div class="row">&nbsp;</div>
                        <input class="btn btn-success" type="submit" value="login" name="login" >
                    </form>
                    <div class="row">&nbsp;</div>
                    <center><b>You are not registered ?</b> <br></b><a href="<?php echo base_url('./indexCI.php/login'); ?>">Register here</a></center>
                    <div class="row">&nbsp;</div>
                </div>
                </center>
            </div>
        </div>
    </div>
</div>
