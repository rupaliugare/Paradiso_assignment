<?php
class Users_controller extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
    }
    public function index()
    {
        $data['page_title'] = "Login Registration";
        $this->session->set_flashdata('error_msg', '');
        $this->session->set_flashdata('success_msg', '');
        $data['main_content'] = array('user_login/register');
        $this -> load -> view('bootstrap_templates/main_template', $data);
    }

    public function register_user()
    {
        $json_data = array(
            "email"=> $this->input->post('user_email'),
            "password"=> $this->input->post('user_password')
        );
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://reqres.in/api/register',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => json_encode($json_data),
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
          ),
        ));
        $response = curl_exec($curl);

        $http_code = curl_getinfo($curl,CURLINFO_HTTP_CODE);
        $err = curl_error($curl);
        curl_close($curl);
        if ($http_code != 200) {
            $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
            redirect('login/login_view');
        } else {
          $this->session->set_flashdata('success_msg', 'Registered successfully.Now login to your account.');
            redirect('login/login_view');
        }
    }

    public function login_view()
    {
        $data['page_title'] = "Login to Your Account";
        $data['main_content'] = array('user_login/login');
        $this -> load -> view('bootstrap_templates/main_template', $data);
    }

    public function login_user()
    { 
        $json_data = array(
            "email"=> $this->input->post('user_email'),
            "password"=> $this->input->post('user_password')
        );
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://reqres.in/api/login',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => json_encode($json_data),
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
          ),
        ));
        $response = curl_exec($curl);
        $http_code = curl_getinfo($curl,CURLINFO_HTTP_CODE);
        $err = curl_error($curl);
        curl_close($curl);
        if ($http_code != 200) {
            $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
            $data['main_content'] = array('user_login/login');
            $this -> load -> view('bootstrap_templates/main_template', $data);
        } else {
            $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => 'https://reqres.in/api/users',
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'GET',
            ));
            $response = curl_exec($curl);
            $http_code = curl_getinfo($curl,CURLINFO_HTTP_CODE);
            $err = curl_error($curl);
            curl_close($curl);
            if ($http_code != 200) {
                $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
                redirect('login/login_user');
            } else {
                $data['user_list'] = json_decode($response);
                $data['main_content'] = array('user_login/user_profile');
                $this -> load -> view('bootstrap_templates/main_template', $data);
            }
        }
    }

    public function user_logout()
    {
        $this->session->sess_destroy();
        redirect('login/login_view', 'refresh');
    }

    public function add_user()
    {
        $json_data = array(
            "name"=> $this->input->post('user_name'),
            "job"=> $this->input->post('user_job')
        );
        $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => 'https://reqres.in/api/users',
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'POST',
              CURLOPT_POSTFIELDS => json_encode($json_data),
              CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/json'
              ),
            ));
            $response = curl_exec($curl);
            $http_code = curl_getinfo($curl,CURLINFO_HTTP_CODE);
            $err = curl_error($curl);
            curl_close($curl);
            if ($http_code != 200) {
                echo "0";return;
            } else {
               echo "1";return;
            }
    }

    public function ajax_update_user()
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://reqres.in/api/users/2',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'PUT',
          CURLOPT_POSTFIELDS =>'{
            "name": "ABC",
            "job": "Teacher"
        }',
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
          ),
        ));
            $response = curl_exec($curl);
            $http_code = curl_getinfo($curl,CURLINFO_HTTP_CODE);
            $err = curl_error($curl);
            curl_close($curl);
            if ($http_code != 200) {
                echo "0";return;
            } else {
               echo "1";return;
            }   
    }

    public function ajax_delete_user()
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://reqres.in/api/users/2',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'DELETE',
        ));
        $response = curl_exec($curl);
            $http_code = curl_getinfo($curl,CURLINFO_HTTP_CODE);
            $err = curl_error($curl);
            curl_close($curl);
        if ($http_code != 200) {
            echo "0";return;
        } else {
           echo "1";return;
        } 
    }
}
?>