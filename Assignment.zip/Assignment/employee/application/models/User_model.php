<?php
class User_model extends CI_model{
 
    public function fetch_employees_manager()
    {
        $this->db->select('*');
        $this->db->from('employee_list');
        $this->db->where('manger_id',0);
        if($query = $this->db->get())
        {
            return $query->result_array();
        }else{
            return NULL;
        }
    }

    public function fetch_employees()
    {
        $this->db->select('*');
        $this->db->from('employee_list');
        $this->db->where('manger_id != 0');
        if($query = $this->db->get())
        {
            return $query->result_array();
        }else{
            return NULL;
        }
    }

    public function fetch_employees_of_emp($user_id)
    {
        $this->db->select('*');
        $this->db->from('employee_list');
        $this->db->where('manger_id',$user_id);
        if($query = $this->db->get())
        {
            return $query->result_array();
        }else{
            return NULL;
        }
    }
}
?>