<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            ul, #myUL {
              list-style-type: none;
            }

            #myUL {
              margin: 0;
              padding: 0;
            }

            .caret {
              cursor: pointer;
              -webkit-user-select: none; /* Safari 3.1+ */
              -moz-user-select: none; /* Firefox 2+ */
              -ms-user-select: none; /* IE 10+ */
              user-select: none;
            }

            .caret::before {
              content: "\25B6";
              color: black;
              display: inline-block;
              margin-right: 6px;
            }

            .caret-down::before {
              -ms-transform: rotate(90deg); /* IE 9 */
              -webkit-transform: rotate(90deg); /* Safari */'
              transform: rotate(90deg);  
            }

            .nested {
              display: none;
            }

            .active {
              display: block;
            }
        </style>
    </head>
    <body>
        <fieldset>
            <?php 
                foreach($employee_list_data as $emp_key=>$emp_val)
                {
                    ?>
                    <ul id="myUL">
                        <li><span class="caret"><?php echo $emp_val['name'];?></span>
                            <ul class="nested">
                                <?php 
                                if(is_array($emp_val['emp_id']))
                                {
                                    foreach($emp_val['emp_id'] as $value)
                                    {
                                        ?> 
                                        <li><span class="caret"><?php echo $value['employee'];?></span>
                                            <?php 
                                            if(is_array($value['emp_id']))
                                            {
                                                ?>
                                                <ul class="nested">
                                                <?php
                                                foreach($value['emp_id'] as $emp_value)
                                                {
                                                ?>
                                                    <li><span class="caret"><?php echo $emp_value['employee'];?></span>
                                                        <?php 
                                                        if(is_array($emp_value['emp_id']))
                                                        {
                                                            ?>
                                                            <ul class="nested">
                                                            <?php
                                                            foreach($emp_value['emp_id'] as $emp_emp_value)
                                                            {
                                                            ?>
                                                                <li><span class="caret"><?php echo $emp_emp_value['employee'];?></span></li>
                                                            <?php
                                                            }
                                                            ?>
                                                            </ul>
                                                            <?php
                                                        }
                                                        ?>
                                                    </li>
                                                    <?php
                                                }
                                                ?>
                                                </ul>
                                                <?php
                                            }?>  
                                        </li>
                                        <?php
                                        }
                                    }
                                    ?>
                                </li>  
                            </ul>
                    <?php
                }
            ?>
        </fieldset>
        <script>
            var toggler = document.getElementsByClassName("caret");
            var i;
            for (i = 0; i < toggler.length; i++) {
              toggler[i].addEventListener("click", function() {
                this.parentElement.querySelector(".nested").classList.toggle("active");
                this.classList.toggle("caret-down");
              });
            }
        </script>
    </body>
</html>