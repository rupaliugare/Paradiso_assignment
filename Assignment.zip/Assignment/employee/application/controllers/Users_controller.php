<?php

class Users_controller extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
    }

    public function index()
    {
        $manager_fetch_query = $this -> user_model -> fetch_employees_manager();
        if($manager_fetch_query != NULL)
        {
            $manager_fetch = $manager_fetch_query; 
        }else{
            $manager_fetch = NULL; 
        }  

        $employee_fetch_query = $this -> user_model -> fetch_employees();
        if($employee_fetch_query != NULL)
        {
            $employee_fetch = $employee_fetch_query; 
        }else{
            $employee_fetch = NULL; 
        }  

        $temp_employee = array();
        foreach ($manager_fetch as $man_key => $man_value) 
        {
            for($i=0;$i < count($employee_fetch);$i++) 
            {
                if($man_value['user_id'] == $employee_fetch[$i]['manger_id'])
                {
                    $temp_data = array('employee' => $employee_fetch[$i]['name'], 'user_id' => $employee_fetch[$i]['user_id'],'manger_id' => $employee_fetch[$i]['manger_id']);
                    $manager_fetch[$man_key]['emp_id'][$i] = $temp_data;
                }else{
                    $temp_data = array('employee' => $employee_fetch[$i]['name'], 'user_id' => $employee_fetch[$i]['user_id'],'manger_id' => $employee_fetch[$i]['manger_id']);
                    $temp_employee[$employee_fetch[$i]['manger_id']] = $temp_data;
                    $emp_of_emp = $this->employee_of_employee($employee_fetch[$i]['user_id'],$temp_employee,$employee_fetch[$i]['manger_id']);
                    if($emp_of_emp != NULL)
                    {
                        $temp_employee = $emp_of_emp;
                    }
                }
            }
        } 

        foreach ($manager_fetch as $man_key => $man_value) 
        {
            foreach ($temp_employee as $emp_key => $emp_value) 
            {
                foreach ($man_value['emp_id'] as $key => $value) {
                    if($value['user_id'] == $emp_value['manger_id'])
                    {
                        $manager_fetch[$man_key]['emp_id'][$key]['emp_id'][$man_key] = $emp_value;
                    }
                }
            }
        } 
        
        $data['employee_list_data'] = $manager_fetch;
        $this -> load -> view('employee_view/employee_list', $data);
    }

    public function employee_of_employee($user_id,$temp_employee,$manger_id)
    {
        $emp_of_array = array();
        $employee_temp_fetch_query = $this -> user_model -> fetch_employees_of_emp($user_id);

        if($employee_temp_fetch_query != NULL)
        {
            foreach ($employee_temp_fetch_query as $key => $value) 
            {
                $temp_data = array('employee' => $value['name'], 'user_id' => $value['user_id'],'manger_id'=>$value['manger_id']);
                $temp_employee[$manger_id]['emp_id'][$key] = $temp_data;
            }
        }else{
            $temp_employee = NULL;
        } 
        return $temp_employee;
    }
}
?>