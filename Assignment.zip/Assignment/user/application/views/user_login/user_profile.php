<style type="text/css">
  .table_blue_color th
    {
        color: #fff;
        background-color: #428bca;
        border-color: #357ebd;
        font-weight: 400;
        text-align: center;
    }
</style>
<script type="text/javascript">
    function add_user() 
    {
        var user_name = $("#user_name").val();
        var user_job = $("#user_job").val();
        if($('#user_name').val() == '' || $('#user_name').val() == null)
        {
            alert("Please enter User Name");
            $('#user_name').focus();
            return;
        }
        if($('#user_job').val() == '' || $('#user_job').val() == null)
        {
            alert("Please enter USer Email Id");
            $('#user_job').focus();
            return;
        }
        var controller = 'login';
        var base_url = '<?php echo site_url(); ?>'; 
        var url = base_url + '/' + controller + '/' + 'add_user' ;
        $.ajax
        ({
            'url' :  url,
            'type' : 'POST', 
            'data' : {'user_name':user_name,'user_job':user_job},
            'success' : function(html_data)
            {   
                if(html_data !=0)
                {
                    alert('User Added successfully!');
                    location.reload();
                }else{
                    alert('Something went wrong. Please try again!');
                    return false;
                }
            }
        });
    }

    function edit_user()
    {
        var controller = 'login';
        var base_url = '<?php echo site_url(); ?>'; 
        var url = base_url + '/' + controller + '/' + 'ajax_update_user' ;
        $.ajax
        ({
            'url' :  url,
            'type' : 'POST', 
            'data' : {},
            'success' : function(html_data)
            {   
                if(html_data !=0)
                {
                    alert('User edited successfully!');
                        location.reload();
                }else{
                    alert('Something went wrong. Please try again!');
                    return false;
                }
            }
        });
    }

    function delete_user() 
    {
        var base_url = '<?php echo site_url(); ?>'; 
        var url = base_url + '/' + 'login' + '/' + 'ajax_delete_user';
        $.ajax
        ({
            'url' :  url,
            'type' : 'POST',
            'data' : {
            },
            'async' :false,
            success : function(data)
            {   
                if(data != 0){
                    alert("User deleted successfully!");
                    location.reload();
                }else{
                    alert("Something wants wrong!");
                    return;
                }
            }
        });
    }
</script>
<ul class="sky-mega-menu sky-mega-menu-response-to-icons">
	<!-- Right Section Start -->
	<div style="float: right;">
		<li>&nbsp;</li>
		<li>
			<li aria-haspopup="true">
				<a href = "http://localhost/user/indexCI.php/login/user_logout">
					<i class="fa fa-sign-out"></i><?php echo $_SESSION['user_name'];?>
				</a>
			</li>
		</li>
	</div>
</ul>			
<div class="container-fluid" >
    <span style="float: left;color:black;"><h4><b><i></i><?php echo "User List"; ?></b></h4></span>
    <span style="float: right;color:black;"><h4><b><i class="fa fa-calendar"></i> <?php echo date("d M Y"); ?></b></h4></span>
    <br>
    <br>
    <br> 
	<center>
		<a class="modalbox btn btn-primary"  style="margin-bottom:1%;margin-top:1%;" href="#ex1" id="add_button" data-target="#ex1" data-toggle="modal">Add User</a>
        <input class="btn btn-primary" type="button" value="Edit User" name="edit_user" onclick="edit_user();">
        <input class="btn btn-primary" type="button" value="Delete User" name="delete_user" onclick="delete_user()";>
	</center>	
	<?php if ($user_list != NULL) {?>
    <div class="table-responsive">
		<table class="table table-bordered table-striped table-condensed table_blue_color" id="user_rapid_list">
            <thead>
                <tr>
                    <th class="text-center">Sr No</th>
					<th class="text-center">User Name</th>
					<th class="text-center">User Email</th>
					<th class="text-center">User avatar</th>
				</tr>
            </thead>
            <tbody>
                <?php
                   foreach ($user_list->data as $key => $user_data)
                   {
                    ?>
                    <tr>
                        <td>
                            <input type="hidden" value="<?php echo $key++; ?>">
                            <?php echo $key; ?>
                        </td>
                        <td id="user_exi_name<?php echo $key; ?>"><?php echo $user_data->first_name." ".$user_data->last_name; ?></td>
                        <td id="email<?php echo $key; ?>">
                        	<?php echo $user_data->email;?>
                        </td>
                        <td id="avatar<?php echo $key; ?>">
                            <?php echo $user_data->avatar;?>
                        </td>		
                    </tr>
                    <?php
                   }?>
            </tbody>
        </table>
    </div>
    <?php }?>
    <div class="modal fade" id="ex1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="padding-top: 10%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><b>Use Information</b></h4>
            </div>
            <div class="modal-body">
                <div class="row text-center">
                    <div class="col-md-2 text-left">
                        <label>User Name :</label>
                    </div>
                    <div class="col-md-4">
                        <input class="form-control" placeholder="Please enter Name" name="user_name" id="user_name" type="text" required>
                    </div>
                    <div class="col-md-2 text-left">
                        <label>User Job</label>
                    </div>
                    <div class="col-md-4">
                        <input class="form-control" placeholder="Enter Job" name="user_job" id="user_job" type="text" required>
                    </div>
                </div>
                <br>
                <div class="row text-center">
                    <button class="btn btn-primary" id="class_changes_add"  type="button" onClick="add_user();" data-dismiss="modal">Add</button>
                </div>
            </div>        
        </div>
    </div>
</div>