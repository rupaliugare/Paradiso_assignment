<span>
    <div class="container" style="margin-top: 5%">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-info">
                    <div class="panel-heading">
                        <center>
                            <h3 class="panel-title">Please do Registration here</h3>
                        </center>
                    </div>
                    <center>
                    <div class="panel-body">
                        <?php
                        $error_msg = $this->session->flashdata('error_msg');
                        if($error_msg){
                            echo $error_msg;
                        }            
                        ?>
                        <form role="form" method="post" action="<?php echo base_url('./indexCI.php/login/register_user'); ?>">
                            <div class='row'>
                                <div class="col-md-5 text-left">
                                    <label>User Email :</label>
                                </div>
                                <div class="col-md-6">
                                    <input class="form-control" placeholder="Please enter E-mail" name="user_email" type="email" autofocus required>
                                </div>
                            </div>
                            <div class="row">&nbsp;</div>
                            <div class='row'>
                                <div class="col-md-5 text-left">
                                    <label>User Password :</label>
                                </div>
                                <div class="col-md-6">
                                    <input class="form-control" placeholder="Enter Password" name="user_password" type="password" value="" required>
                                </div>
                            </div>
                            <div class="row">&nbsp;</div>
                            <input class="btn btn-primary" type="submit" value="Register" name="register">
                        </form>
                        <div class="row">&nbsp;</div>
                        <center><b>You have Already registered ?</b><br></b><a href="<?php echo base_url('./indexCI.php/login/login_view'); ?>"> Please Login</a></center>
                    </div>
                    </center>
                </div>
            </div>
        </div>
    </div>
</span>