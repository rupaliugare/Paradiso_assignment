	<!-- Content Header Start -->
	<script type="text/javascript" src="<?php echo base_url();?>headercss/js/jquery.min.js"></script>

    <!-- BEGIN PLUGINS STYLE -->
    <link rel="stylesheet" href="<?php echo base_url();?>application/views/bootstrap_templates/bootstrap_css.css">
    <link rel="stylesheet" href="<?php echo base_url();?>CI-js/bootstrap/plugins/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>CI-js/bootstrap/plugins/font-awesome/css/font-awesome.min.css">
    <!-- END PLUGINS STYLE -->

    <!-- BEGIN FRAMEWORK STYLE -->
    <link rel="stylesheet" href="<?php echo base_url();?>CI-js/bootstrap/elements/css/styles.css">
    <link rel="stylesheet" href="<?php echo base_url();?>CI-js/bootstrap/elements/css/styles-responsive.css">
    <link rel="stylesheet" href="<?php echo base_url();?>CI-js/bootstrap/elements/css/plugins.css">
    <!-- END  FRAMEWORK STYLE -->

    <!-- Includes Start-->
    <link rel="stylesheet" href="<?php echo base_url();?>css/sky-mega-menu.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/font-awesome.css">
    <!--/ Includes End-->

    <!-- Jquery Confirm alert start-->
    <script src ="<?php echo base_url();?>CI-js/bootstrap/plugins/bootstrap-alert/jquery-confirm.min.js"></script>
     <!-- Jquery Confirm alert end-->
<!-- Content Header End -->
</head>