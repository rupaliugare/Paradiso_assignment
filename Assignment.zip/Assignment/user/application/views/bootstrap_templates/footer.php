<!-- Styles Include Start -->      
    <link rel="stylesheet" href="<?php echo base_url();?>/css/font-awesome.css"/>
<!-- Styles Include End -->      

<!-- FRAMEWORK SCRIPTS START-->
    <script src="<?php echo base_url();?>CI-js/bootstrap/plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js"></script>
    <script src="<?php echo base_url();?>CI-js/bootstrap/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- FRAMEWORK SCRIPTS END -->
    </body>
</html>