<?php
    $this->load->view('bootstrap_templates/header');
    $this->load->view('bootstrap_templates/content_header', $page_data);
    $count = count($main_content);
    for ($i = 0; $i < $count; $i++) {
        $this->load->view($main_content[$i]);
    }

    $this->load->view('bootstrap_templates/footer');
?>